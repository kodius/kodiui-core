export const m = {
	true: "m-auto",
	x: "mx-auto",
	y: "my-auto",
	s: "ms-auto",
	e: "me-auto",
	t: "mt-auto",
	b: "mb-auto",
	l: "ml-auto",
	r: "mr-auto",
}
