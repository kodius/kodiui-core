export const customColors = {
	brand: "#493DCC",
}

export const customBackgroundColors = {
	brand: "bg-brand",
}

export const customTextColors = {
	brand: "text-brand",
}

export const customBorderColors = {
	brand: "border-brand",
}

export const customBoxShadowColors = {
	brand: "shadow-brand",
}

export const customDecorationColors = {
	brand: "shadow-brand",
}

export const customGradientFromColors = {
	brand: "from-brand",
}

export const customGradientViaColors = {
	brand: "via-brand",
}

export const customGradientToColors = {
	brand: "to-brand",
}
