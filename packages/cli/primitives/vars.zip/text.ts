export const textAlign = {
  left: "text-left",
  center: "text-center",
  right: "text-right",
  justify: "text-justify",
  start: "text-start",
  end: "text-end",
}

export type TextAlign = keyof typeof textAlign
