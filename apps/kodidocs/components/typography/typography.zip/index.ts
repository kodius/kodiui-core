export { Heading } from "./Heading"
export { Text } from "./Text"
