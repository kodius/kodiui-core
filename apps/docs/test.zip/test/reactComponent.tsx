import { Box } from "@kodiui/ui";
import React from "react";

export const ReactComponent = () => {
  return (
    <Box background="blue10">
      <div>reactComponent haaaaa</div>
    </Box>
  );
};
